const add = (a,b) =>{ 
//const p = parseInt("a");
//const q = parseInt("b");
return (parseInt(a) + parseInt(b));
}
const sq = (a,b) => a*b;
module.exports.add = add;