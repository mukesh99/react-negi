const mongoose = require(mongoose)
mongoose.Promise = global.Promise;
const connection = 'mongodb://<dbuser>:<dbpassword>@ds133746.mlab.com:33746/freedb';

mongoose.connect(connection);
module.exports = { mongoose };