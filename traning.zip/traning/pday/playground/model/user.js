const mongoes = require('./connection')

const user = mongoes.model({
     name: string,
     age: number,
     address:string
})
     



