const { expect } = require('chai');
// const addModule = require('./add');
// const result = addModule.add(20,10);
// console.log(result);

// const {add, sq} = require('./add');

// it('should add two numbers', ()=>{
//     const res = add(3, 3);
//     console.log("its coming fine");
//     if(res !==5)
//     {
//         throw new Error("Error Occured");
//     }
// })


const {add, sq} = require('./add');

it('should add two numbers', ()=>{
    const res = add(3, 3);
    console.log("its coming fine");

    expect(res).to.equal(6);
})

it('should return a number', ()=>{
    const res = add('3', 3);
    console.log("its coming fine");

    expect(res).to.be.a('number');
})