const express = require('express')
const bodyParser = require('body-parser')

const app = express()



app.use(bodyParser.json())

 app.post('/note', (req, res) => { 
   res.write('in middleware'); 
  
})  

app.use(express.static(__dirname + '/public'));

// app.use((req, res, next) => {
//    res.write('in middleware'); 
//    next();
// });


app.get('/', (req, res) => { 
    res.write('Hello World!');
    res.end();
})


app.listen(3000, (err) => {
    console.log('Example app listening on port 3000!')
});