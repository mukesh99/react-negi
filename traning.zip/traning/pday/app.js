const express = require('express')
const bodyParser = require('body-parser')
const app = express()
const mongoose = require(mongoose)


app.use(body-Parser.Json());

 app.post('/note', (req, res) => { 
   console.log(req.body);
})  

app.use(express.static(__dirname + '/public'));

app.use((req, res, next) => {
   res.write('in middleware'); 
   next();
});


app.get('/', (req, res) => { 
    res.write('Hello World!');
    res.end();
})


app.listen(3000, (err) => {
    console.log('Example app listening on port 3000!')
});