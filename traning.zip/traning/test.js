//console.log('Hello world');

/*(function(){
    console.log("I am inside");
})()


//console.log(__filename);
//console.log(__dirname);

console.log(process.argv);

var foo = function(a,b) {
    return a+b;
}
function foo(a,b)
{
    return a+b;
}
var foo = (a,b) => {return a+b;}

*/
/*const getUserInput = (flag) => {
    const index = process.argv.indexOf(flag);
    return (index == -1) ? null : process.argv[index + 1 ];
}
const user = getUserInput('--user');  
const age = getUserInput('--age');

//console.log(user);  
//console.log(age); 


//console.log(process.memoryUsage());

/*process.argv.forEach((val, index) => {
  console.log(`${index}: ${val}`);
});
*/
//console.log(`Current directory: ${process.cwd()}`);

/*function printHello(){
   console.log( "Hello, World!");
}
// Now call above function after 2 seconds
setTimeout(printHello, 2000);
*/
/*var questions = [
    "What is your name?",
    "Are you a developer?",
    "What is your preferred programming language?"
  ];

  var answers = [];

  function ask(i) {
    process.stdout.write(`\n\n\n\n ${questions[i]}`);
    process.stdout.write("  >  ");
  }

  process.stdin.on('data', function(data) {

      answers.push(data.toString().trim());

      if (answers.length < questions.length) {
          ask(answers.length);
      } else {
          process.exit();
      }

  });

    process.on('exit', function() {

      process.stdout.write("\n\n\n\n");

      process.stdout.write(`${answers[1]}! You are a great  ${answers[2]} developer, ${answers[0]}`);

      process.stdout.write("\n\n\n\n");

  });

  ask(0);
  */
//const path = require('path');
//const fileDir = path.dirname(__dirname);
//console.log(fileDir);
/*const path = require('path');
const fileDir = path.dirname(__dirname);
path.parse('D:\\path\\dir\\test.js');
*/
/*var fs = require('fs');
content ='My india is great';
fs.readFile('D:/traning/my.txt', 'utf8', function (err,data) {
  if (err) {
    return console.log(err);
  }
  console.log(data);
});
/*var http = require('http');

http.createServer(function (request, response) {
    response.writeHead(200, {
        'Content-Type': 'text/plain',
        'Access-Control-Allow-Origin' : '*'
    });
    response.end('My india is great\n');
}).listen(1337);
console.log("Server started at port 1337");
*/

const https = require("https");
const fs = require("fs");

const options = {
	hostname: "en.wikipedia.org",
	port: 443,
	path: "/wiki/Bangalore",
	method: "GET"
};

const req = https.request(options, function(res) {

	let responseBody = "";

	console.log("Response from wikipedia.");
	console.log(`Server Status: ${res.statusCode} `);
	console.log("Response Headers: %j", res.headers);

    // input stream will be a string
	res.setEncoding("UTF-8");

	res.once("data", function(chunk) {
		console.log('once:-', chunk);
	});

	res.on("data", function(chunk) {
		console.log(`--chunk-- ${chunk.length}`);
		responseBody += chunk;
	});

	res.on("end", function() {
		fs.writeFile("Bangalore.html", responseBody, function(err) {
			if (err) {
				throw err;
			}
			console.log("File Downloaded");
		});
	});

});

req.on("error", function(err) {
	console.log(`There is some problme : ${err.message}`);
});

req.end();