/**
 * App step-1
 */

// const request = require('request');
// var mykey ='AIzaSyAasA_7JY6wXtpuEA9L6vZ2bsKlV0zvesg';
// const URL = `https://maps.googleapis.com/maps/api/geocode/json?key=${mykey}&address=560017`;
// request({
//     url: URL,
//     json: true
// }, (error, response, body) => {
//     console.log(JSON.stringify(response, undefined, 2));
// });

/**
 * Get user input yargs "yargs@10.0.3"
 * Yarg command setup
 * node app.js --address=560017
 */


// const request = require('request');

// var mykey ='AIzaSyAasA_7JY6wXtpuEA9L6vZ2bsKlV0zvesg';
// const address = argv.address;
// const url = `https://maps.googleapis.com/maps/api/geocode/json?key=${mykey}&address=${address}`;
// var request = require('request');

// request({url, json:true},(error, response, body)=> {
//   console.log('error:', error); // Print the error if one occurred


//   //console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received
//   console.log(body.results[0].geometry.location); // Print the HTML for the Google homepage.
//   if(body.status ==='ok')
//   {
//     console.log('We are inside');
//   }
//   else
//   {
//      console.log('Its error is coming'); 
//   }

  
  
// });
const request = require('request');

const wheather = ()=>
{
//var mykey ='AIzaSyAasA_7JY6wXtpuEA9L6vZ2bsKlV0zvesg';
const url = `https://api.darksky.net/forecast/14e3b8d1298a2a9e7ec77407f412ecad/37.8267,-122.4233`;
var request = require('request');

request({url, json:true},(error, response, body)=> {
  //console.log('error:', error); // Print the error if one occurred
    console.log(body.currently.temperature);
});
}
// getGeocode(560078);
//const add = (a,b) => a+b;
module.export = {wheather}
/**
 *  Assignment
 *  @set api url dynamically
 */


// const request = require('request');
// const yargs = require('yargs');
// const encodedAddress = encodeURIComponent(argv.address);
// const argv = yargs
// .options({
//     address: {
//         demand: true,
//         alsias: 'a',
//         describe: 'Address to fetch weather for',
//         string: true
//     }
// })
// .help()
// .alias('help', 'h')
// .argv;

// const URL = `https://maps.googleapis.com/maps/api/geocode/json?key=AIzaSyAwKLUZrAp0T8HCMDHGqFn9nokZm4Jmi_4&address=${encodedAddress}`;

// request({
//     url: URL,
//     json: true
// }, (error, response, body) => {
//     const result = `Address:- ${body.results[0].formatted_address}
//     Latitude:- ${body.results[0].geometry.location.lat}
//     Longitude:- ${body.results[0].geometry.location.lng}`;

// });

/**
 * Assignment -2
 * @ handling Error Callback function
 */


// const request = require('request');
// const yargs = require('yargs');

// const argv = yargs
// .options({
//     address: {
//         demand: true,
//         alsias: 'a',
//         describe: 'Address to fetch weather for',
//         string: true
//     }
// })
// .help()
// .alias('help', 'h')
// .argv;
// var mykey ='AIzaSyAasA_7JY6wXtpuEA9L6vZ2bsKlV0zvesg';
//  const URL = `https://maps.googleapis.com/maps/api/geocode/json?key=mykey&address=${encodedAddress}`;
// request({
//      url: URL,
//      json: true
//  }, (error, response, body) => {
//      if(error) {
//          console.log('Unable to connect to Server');
//      } else if(body.status === 'ZERO_RESULTS') {
//          console.log('Unable to find that address');
//      } else if(body.status === 'OK') {
//         const result = `Address:- ${body.results[0].formatted_address}
//                         Latitude:- ${body.results[0].geometry.location.lat}
//                          Longitude:- ${body.results[0].geometry.location.lng}`;
//          console.log(result);
//      }

//  });