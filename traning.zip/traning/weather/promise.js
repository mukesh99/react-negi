var somepromise = new Promise((resolve, reject) => {
   resolve("hi message has come");
    reject("message is not come");

})

// somepromise.then((message) => {
//     console.log(message);
// })

var somepromise = new Promise((resolve, reject) => {
  setTimeout(function() {
      resolve('Hi its work');
      reject('reject 1');
      console.log('hi');
       reject('reject 2');
  }, 2000);

})

var obj = somepromise.then((message) => {
 console.log('in then', message);
})

